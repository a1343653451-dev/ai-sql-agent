package com.example.demo;
import cn.hutool.http.HttpRequest;
import cn.hutool.json.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AiClient {
    @Value("${ai.api-key}")
    private String apiKey;
    @Value("${ai.url}")
    private String url;

    public String generateSql(String question) {
        String prompt = "生成SQL，只返回SQL: " + question;

        JSONObject body = new JSONObject();
        body.set("model", "gpt-4o-mini");
        body.set("messages", JSONUtil.parseArray("[{\"role\":\"user\",\"content\":\""+prompt+"\"}]"));

        String res = HttpRequest.post(url)
            .header("Authorization", "Bearer " + apiKey)
            .body(body.toString())
            .execute().body();

        return JSONUtil.parseObj(res)
            .getJSONArray("choices")
            .getJSONObject(0)
            .getJSONObject("message")
            .getStr("content");
    }
}
