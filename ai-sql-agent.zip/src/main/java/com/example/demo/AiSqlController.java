package com.example.demo;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/ai")
public class AiSqlController {
    private final AiClient ai;
    private final SqlSafeChecker checker;
    private final SqlService service;

    public AiSqlController(AiClient ai, SqlSafeChecker checker, SqlService service){
        this.ai=ai;this.checker=checker;this.service=service;
    }

    @PostMapping("/query")
    public Object query(@RequestBody Map<String,String> req){
        String q=req.get("question");
        String sql=ai.generateSql(q);
        if(!checker.isSafe(sql)) return "危险SQL:"+sql;
        return service.query(sql);
    }
}
