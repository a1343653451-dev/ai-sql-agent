package com.example.demo;
import org.springframework.stereotype.Component;

@Component
public class SqlSafeChecker {
    public boolean isSafe(String sql){
        sql = sql.toLowerCase();
        return !(sql.contains("delete")||sql.contains("update")||sql.contains("drop"));
    }
}
