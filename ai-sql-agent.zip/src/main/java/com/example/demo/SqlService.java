package com.example.demo;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class SqlService {
    private final JdbcTemplate jdbcTemplate;
    public SqlService(JdbcTemplate jdbcTemplate){this.jdbcTemplate=jdbcTemplate;}
    public List<Map<String,Object>> query(String sql){
        return jdbcTemplate.queryForList(sql);
    }
}
